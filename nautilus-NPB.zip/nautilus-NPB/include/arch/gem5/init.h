#ifndef __INIT_H__
#define __INIT_H_


void init(unsigned long mbd, unsigned long magic);

#endif
