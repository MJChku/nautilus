#ifndef __MAIN_H__
#define __MAIN_H__

void main (unsigned long mbd, unsigned long magic);


#endif
