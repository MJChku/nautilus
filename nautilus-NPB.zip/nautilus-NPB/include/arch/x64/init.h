#ifndef __INIT_H__
#define __INIT_H__


void init(unsigned long mbd, unsigned long magic);

#endif
