char* read_lua_script();
