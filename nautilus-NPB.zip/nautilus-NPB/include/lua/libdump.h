#ifdef __cplusplus
extern "C" {
#endif

#include "nautilus/nautilus.h"

typedef void FILE;

int feof(FILE*);


#ifdef __cplusplus
}
#endif

