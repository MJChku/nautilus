err_t ethernetif_init(struct netif *netif);
