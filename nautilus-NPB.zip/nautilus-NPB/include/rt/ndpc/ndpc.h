//
// Copyright (c) 2017 Peter Dinda  All Rights Reserved
//


#ifndef _ndpc_rt
#define _ndpc_rt

int  nk_ndpc_init();
void nk_ndpc_deinit();


#endif
