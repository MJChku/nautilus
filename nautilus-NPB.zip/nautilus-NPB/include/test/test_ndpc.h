#ifndef _TEST_NPDC
#define _TEST_NDPC

int test_ndpc();

#endif
