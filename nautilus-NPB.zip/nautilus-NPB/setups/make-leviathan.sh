make CROSS_COMPILE=/usr/local/nautilus-toolchain/bin/ $*
